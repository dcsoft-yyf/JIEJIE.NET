﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCNETProtector
{
    internal class ComponentResourceManagerInfo
    {
        public int LineIndex = 0;
        public DCILMethod Method = null;
        public DCILClass MyClass = null;
        public string ClassName = null;
    }
}
